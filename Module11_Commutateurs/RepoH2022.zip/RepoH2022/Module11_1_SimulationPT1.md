## Simulation PT  - configuration  de base d'un commutateur

## Objectifs

- Sécuriser l'accès total au commutateur 

- Sécuriser les ports ```console``` et ```VTY```

- Sauvegarder la configuration de mémoire RAM en mémoire SVRAM


- Décompressez le fichier ./Exercices/ ```2.5.5 Packet Tracer - Configure Initial Switch Settings.zip``` sur votre poste de travail.

- L'activité  PT est contenue dans le fichier .pka.  