## Simulation PT  - configuration  de base d'un commutateur

## Objectifs

- Configurer l'Interface SVI 

- Configurer le commutateur à distance

- Décompressez le fichier ./Exercices/ ```2.7.6 Packet Tracer - Implement Basic Connectivity.zip``` sur votre poste de travail.

- L'activité  PT est contenue dans le fichier .pka. 
 