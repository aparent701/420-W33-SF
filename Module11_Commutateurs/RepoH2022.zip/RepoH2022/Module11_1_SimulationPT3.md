## Simulation PT  -  synthèes de la configuration d'un commutateur

## Objectifs

- Utiliser l'ensemble des commandes pour configurer des commutateurs 

- Assurer la connectivité entre les postes locaux

- Décompressez le fichier ./Exercices/ ```2.9.1 Packet Tracer - Basic Switch and End Device Configuration.zip``` sur votre poste de travail.

- L'activité  PT est contenue dans le fichier .pka. 
 