# Module 10 - Configuration des routeurs: routes statiques

Objectifs :

- Configurer des interfaces de routeurs

- Configurer des routes statiques

- Configurer d'une route par défaut

NOTE: hôte et périphérique sont considérés synonymes

- 1 [Théorie](./Module11__1_Théorie.md)

- 2 [Configuration de base](./Module11_1_SimulationPT1.md)

- 3 [Configuration de l'interface SVI](./Module11_1_SimulationPT2.md)

- 4  [Configuration des routes statiques avance](./Module11_1_SimulationPT3.md)

FIn des exercices du module 

