## Théorie  - configuration des commutateurs

## Objectifs

- Configurer l'interface vituelle 

- Sécuriser les commutateurs par des mots de passe 

- Vérifier l'adressabilité complète entre périphériques

## Lecture

-  Lire le fichier suivant.  Notez les différentes commandes, leur rôle et la syntaxe.

./Module_11Commutateur.pdf
 
## Documenter la configuration pour votre révision

- Durant la lecture, ajouter les commandes que vous retrouvez dans le fichier  ./Exercices/ ```configSwitch_RouteurVBeta.xls``` .
